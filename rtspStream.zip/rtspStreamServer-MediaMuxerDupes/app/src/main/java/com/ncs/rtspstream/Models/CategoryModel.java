package com.ncs.rtspstream.Models;


public class CategoryModel {

    public String categoryName;
    public int drawable;

    public CategoryModel(String categoryName, int drawable) {
        this.categoryName = categoryName;
        this.drawable = drawable;
    }

}
