package com.ncs.rtspstream.ViewModel;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.ncs.rtspstream.R;


public class PlaceDialogBox {

    private Dialog customDialog;
    private String placeName = "";
    private String openingHours = "";
    private String contactNumber = "";
    private String about = "";
    private int level;
    private TextView mTextViewPlaceName, mTextViewLevelLocated, mTextViewOpeningHours, mTextViewContactInfo, mTextViewPlaceDesc;
    private ImageButton mButtonClose;

    private ImageView mImageViewPlaceImage;
    int dialogPlaceImage;

    private Context context;

    public PlaceDialogBox(Context context)
    {
        customDialog = new Dialog(context);
        openDialogBox();
    }

    private void openDialogBox()
    {
        customDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        customDialog.setContentView(R.layout.place_dialog_box);
        View v = customDialog.getWindow().getDecorView();

        mButtonClose = (ImageButton) customDialog.findViewById(R.id.imageButtonCloseDialog);


        v.setBackgroundResource(android.R.color.transparent);
        //App.app.activity = ((Activity) context);

        mButtonClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                customDialog.dismiss();
            }
        });

        customDialog.show();
    }
}
